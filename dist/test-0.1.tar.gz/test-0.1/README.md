#mypackage
This library was created for the test on how to publish your own Python package.

##building this package locally
'python setup.py sdist'

## installing this package from github
'pip install git+https://github.com/lindobmasina/test.git'

## updating this package from github
'pip install --upgrade git+https://github.com/lindobmasina/test.git'
